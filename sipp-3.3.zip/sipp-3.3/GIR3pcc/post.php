<?php

header("HTTP/1.0 200 OK");

?>
